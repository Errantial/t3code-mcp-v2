import type { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { z } from "zod";
import type { T3Client } from "../client.js";
import { attentionOf, newId, nowIso, threadRequests } from "../model.js";
import type { Attention } from "../model.js";
import {
  activityOverview,
  errorResult,
  jsonResult,
  messageRow,
  relTime,
  threadRow,
} from "../format.js";
import {
  MAX_MESSAGE_CHARS_CEILING,
  MAX_MESSAGE_CHARS_ENV,
  MESSAGE_DEFAULTS,
  sliceMessage,
} from "../message.js";
import {
  DEFAULT_SINCE_HOURS,
  filterThreads,
  pageFields,
  paginate,
} from "../query.js";

const ATTENTION_VALUES = [
  "needs-approval",
  "needs-input",
  "plan-ready",
  "working",
  "error",
  "done",
  "idle",
] as const;

export function registerPhase1(server: McpServer, getClient: () => T3Client) {
  server.registerTool(
    "t3_status",
    {
      title: "T3 Code status",
      description:
        "Check the local T3 Code server: is it running, is auth working, and a summary of " +
        "projects/threads (how many are working, how many need attention). Use this first if " +
        "anything else fails.",
      inputSchema: {},
    },
    async () => {
      try {
        const client = getClient();
        const env = await client.probe();
        const authState = await client.authState();
        let readCompatible = false;
        let commandChannelReady = false;
        let commandError: string | undefined;
        let summary: Record<string, unknown> = {};
        try {
          const shell = await client.shell();
          readCompatible = true;
          const active = shell.threads.filter((t) => !t.archivedAt);
          const byAttention: Record<string, number> = {};
          for (const t of active) {
            const a = attentionOf(t);
            byAttention[a] = (byAttention[a] ?? 0) + 1;
          }
          summary = {
            projects: shell.projects.length,
            threads: {
              total: shell.threads.length,
              active: active.length,
              byAttention,
            },
          };
        } catch (e) {
          summary = {
            compatibilityError: e instanceof Error ? e.message : String(e),
          };
        }
        if (readCompatible) {
          try {
            commandChannelReady = await client.commandReady();
          } catch (e) {
            commandError = e instanceof Error ? e.message : String(e);
          }
        }
        return jsonResult({
          running: true,
          origin: client.origin,
          environment: env.label,
          serverVersion: env.serverVersion,
          authOk: authState.authenticated,
          orchestrationProtocol: 2,
          readCompatible,
          commandChannelReady,
          canOperate: (
            authState.permissions ??
            authState.scopes ??
            []
          ).includes("orchestration:operate"),
          ...(commandError ? { commandError } : {}),
          ...summary,
        });
      } catch (e) {
        return errorResult(e);
      }
    },
  );

  server.registerTool(
    "list_projects",
    {
      title: "List T3 projects",
      description:
        "List the projects (workspaces/repos) registered in T3 Code, with per-project counts of " +
        "active and attention-needing threads.",
      inputSchema: {},
    },
    async () => {
      try {
        const shell = await getClient().shell();
        const counts = new Map<
          string,
          { active: number; needsAttention: number }
        >();
        for (const t of shell.threads) {
          if (t.archivedAt) continue;
          const c = counts.get(t.projectId) ?? { active: 0, needsAttention: 0 };
          c.active++;
          const a = attentionOf(t);
          if (
            a === "needs-approval" ||
            a === "needs-input" ||
            a === "plan-ready" ||
            a === "error"
          )
            c.needsAttention++;
          counts.set(t.projectId, c);
        }
        const projects = shell.projects
          .filter((p) => !p.deletedAt)
          .map((p) => ({
            projectId: p.id,
            title: p.title,
            workspaceRoot: p.workspaceRoot,
            defaultModel: p.defaultModelSelection
              ? `${p.defaultModelSelection.instanceId}/${p.defaultModelSelection.model}`
              : null,
            activeThreads: counts.get(p.id)?.active ?? 0,
            threadsNeedingAttention: counts.get(p.id)?.needsAttention ?? 0,
          }))
          .sort((a, b) => b.activeThreads - a.activeThreads);
        return jsonResult({ projects });
      } catch (e) {
        return errorResult(e);
      }
    },
  );

  server.registerTool(
    "list_threads",
    {
      title: "List T3 threads",
      description:
        "List agent threads in T3 Code, most recently updated first. Defaults to active or " +
        "recent non-archived threads; archived and old done/idle/error threads are opt-in. " +
        "Filter by project or attention state. Each row includes the thread's attention " +
        "state — what, if anything, it needs from the human. Use nextCursor to page.",
      inputSchema: {
        projectId: z
          .string()
          .optional()
          .describe("Only threads in this project"),
        attention: z
          .enum(ATTENTION_VALUES)
          .optional()
          .describe("Only threads in this attention state"),
        includeArchived: z
          .boolean()
          .optional()
          .describe("Include archived threads (default false)"),
        includeInactive: z
          .boolean()
          .optional()
          .describe(
            "Include old done/idle/error threads (default false: only active or recent)",
          ),
        sinceHours: z
          .number()
          .min(1)
          .max(720)
          .optional()
          .describe(
            `Recency window for done/idle/error threads (default ${DEFAULT_SINCE_HOURS}h)`,
          ),
        limit: z
          .number()
          .int()
          .min(1)
          .max(100)
          .optional()
          .describe("Max rows (default 25)"),
        cursor: z
          .string()
          .optional()
          .describe("Opaque nextCursor from a previous list_threads call"),
      },
    },
    async (args) => {
      try {
        const shell = await getClient().shell(args.includeArchived ?? false);
        const projectsById = new Map(shell.projects.map((p) => [p.id, p]));
        const threads = filterThreads(shell.threads, {
          includeArchived: args.includeArchived,
          includeInactive: args.includeInactive,
          sinceHours: args.sinceHours,
        })
          .filter((t) =>
            args.projectId ? t.projectId === args.projectId : true,
          )
          .filter((t) =>
            args.attention
              ? attentionOf(t) === (args.attention as Attention)
              : true,
          )
          .sort((a, b) => Date.parse(b.updatedAt) - Date.parse(a.updatedAt));
        const page = paginate(threads, args.limit ?? 25, args.cursor);
        return jsonResult({
          ...pageFields(page),
          threads: page.items.map((t) => threadRow(t, projectsById)),
        });
      } catch (e) {
        return errorResult(e);
      }
    },
  );

  server.registerTool(
    "get_thread",
    {
      title: "Read a T3 thread",
      description:
        "Read a thread's bounded recent conversation window, session status, " +
        "any pending approval/user-input requests (with requestIds needed to respond), and an " +
        "activity overview. Use beforeCursor from a previous call to page further back. Every " +
        "message row carries messageId, totalChars and truncated; when truncated is true, read " +
        "the rest with get_message.",
      inputSchema: {
        threadId: z.string().describe("Thread id (from list_threads)"),
        turnLimit: z
          .number()
          .int()
          .min(1)
          .max(50)
          .optional()
          .describe(
            "Legacy turn-count hint; v2 uses server-bounded pages and returns pagination metadata",
          ),
        beforeCursor: z
          .string()
          .optional()
          .describe("Pagination cursor from a previous call"),
        includeActivities: z
          .boolean()
          .optional()
          .describe("Include per-activity detail overview (default true)"),
        maxChars: z
          .number()
          .int()
          .min(1)
          .max(MAX_MESSAGE_CHARS_CEILING)
          .optional()
          .describe(
            `Max characters per message row (default ${MESSAGE_DEFAULTS.threadRow}, or ${MAX_MESSAGE_CHARS_ENV})`,
          ),
      },
    },
    async (args) => {
      try {
        const snap = await getClient().thread(args.threadId, {
          turnLimit: args.turnLimit ?? 5,
          beforeCursor: args.beforeCursor,
        });
        const t = snap.thread;
        const pending = threadRequests(t);
        return jsonResult({
          threadId: t.id,
          title: t.title,
          attention: attentionOf(t),
          session: {
            status: t.session?.status ?? "none",
            provider: t.session?.providerName ?? null,
            providerInstanceId: t.session?.providerInstanceId ?? null,
            providerThreadId: t.session?.providerThreadId ?? null,
            providerSessionId: t.session?.providerSessionId ?? null,
            lastError: t.session?.lastError ?? null,
          },
          latestTurn: t.latestTurn
            ? {
                state: t.latestTurn.state,
                completed: relTime(t.latestTurn.completedAt),
              }
            : null,
          model: t.modelSelection
            ? `${t.modelSelection.instanceId}/${t.modelSelection.model}`
            : null,
          branch: t.branch ?? null,
          runtimeMode: t.runtimeMode,
          interactionMode: t.interactionMode,
          pendingRequests: pending,
          messages: (t.messages ?? []).map((m) =>
            messageRow(m, args.maxChars),
          ),
          ...(args.includeActivities === false
            ? {}
            : { activities: activityOverview(t.activities ?? []) }),
          page: snap.page ?? null,
        });
      } catch (e) {
        return errorResult(e);
      }
    },
  );

  server.registerTool(
    "get_message",
    {
      title: "Read one message in full",
      description:
        "Read a single message by id, in slices, with no lossy truncation. get_thread and " +
        "wait_for_turn return messageId and totalChars on every row; when a row is truncated, " +
        "call this repeatedly with the returned nextOffset until it is null. Defaults to " +
        `${MESSAGE_DEFAULTS.getMessage} chars per call (${MAX_MESSAGE_CHARS_ENV} overrides it, ` +
        `hard ceiling ${MAX_MESSAGE_CHARS_CEILING}).`,
      inputSchema: {
        threadId: z.string().describe("Thread id (from list_threads)"),
        messageId: z
          .string()
          .describe("Message id (messageId on a get_thread/wait_for_turn row)"),
        offset: z
          .number()
          .int()
          .min(0)
          .optional()
          .describe("Character offset to start at (default 0; use nextOffset)"),
        maxChars: z
          .number()
          .int()
          .min(1)
          .max(MAX_MESSAGE_CHARS_CEILING)
          .optional()
          .describe(
            `Max characters to return in this slice (default ${MESSAGE_DEFAULTS.getMessage})`,
          ),
      },
    },
    async (args) => {
      try {
        const client = getClient();
        // The message may sit just outside the bounded recent window, so walk
        // back a few server pages before giving up.
        const maxPages = 10;
        let snap = await client.thread(args.threadId);
        let message = (snap.thread.messages ?? []).find(
          (m) => m.id === args.messageId,
        );
        let pages = 1;
        while (
          !message &&
          snap.page?.hasMore &&
          snap.page.beforeCursor &&
          pages < maxPages
        ) {
          snap = await client.thread(args.threadId, {
            beforeCursor: snap.page.beforeCursor,
          });
          message = (snap.thread.messages ?? []).find(
            (m) => m.id === args.messageId,
          );
          pages++;
        }
        if (!message)
          return errorResult(
            new Error(
              `No message ${args.messageId} on thread ${args.threadId} in the last ` +
                `${pages} page(s) of history. Check the id against get_thread, or page ` +
                `further back with get_thread's beforeCursor.`,
            ),
          );
        return jsonResult(
          sliceMessage(message, {
            offset: args.offset,
            maxChars: args.maxChars,
          }),
        );
      } catch (e) {
        return errorResult(e);
      }
    },
  );

  server.registerTool(
    "send_message",
    {
      title: "Send a message to a T3 thread",
      description:
        "Send a user message to an existing thread and start an agent turn. Reuses the thread's " +
        "current model, runtime mode, and interaction mode unless overridden. If the agent is " +
        "mid-turn the message is queued by T3. Returns immediately; use wait_for_turn or " +
        "get_thread to see the reply.",
      inputSchema: {
        threadId: z.string().describe("Thread id (from list_threads)"),
        message: z.string().min(1).describe("The message text to send"),
        runtimeMode: z
          .enum([
            "approval-required",
            "auto-accept-edits",
            "auto",
            "full-access",
          ])
          .optional()
          .describe("Override permission mode for this turn onward"),
        interactionMode: z.enum(["default", "plan"]).optional(),
      },
    },
    async (args) => {
      try {
        const client = getClient();
        const t = await client.detail(args.threadId);
        const command = {
          type: "thread.turn.start",
          commandId: newId(),
          threadId: t.id,
          message: {
            messageId: newId(),
            role: "user",
            text: args.message,
            attachments: [],
          },
          runtimeMode: args.runtimeMode ?? t.runtimeMode,
          interactionMode:
            args.interactionMode ?? t.interactionMode ?? "default",
          createdAt: nowIso(),
        };
        const result = await client.dispatch(command);
        return jsonResult({
          sent: true,
          threadId: t.id,
          threadTitle: t.title,
          sequence: result.sequence,
          runId: result.runId,
          messageId: result.messageId,
          wasBusy: t.session?.activeTurnId ? true : false,
          note: "Turn started. Use wait_for_turn or get_thread to read the reply.",
        });
      } catch (e) {
        return errorResult(e);
      }
    },
  );
}
